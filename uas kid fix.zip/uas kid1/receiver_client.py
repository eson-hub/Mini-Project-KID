import base64
import requests

from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.fernet import Fernet
from cryptography.exceptions import InvalidSignature

SERVER = "http://localhost:8080"
RECEIVER = "jule"
SENDER = "nasihuy"

# LOGIN
login_resp = requests.post(
    f"{SERVER}/login",
    json={"user_id": RECEIVER}
)
login_resp.raise_for_status()

TOKEN = login_resp.json()["access_token"]
headers = {"Authorization": f"Bearer {TOKEN}"}

# LOAD PRIVATE RSA KEY (RECEIVER)
with open("punkhazard-keys/jule_rsa_priv.pem", "rb") as f:
    receiver_private_key = serialization.load_pem_private_key(
        f.read(),
        password=None
    )

with open(f"data/{SENDER}_pubkey.txt", "rb") as f:
    sender_public_key = serialization.load_pem_public_key(f.read())

# GET INBOX
response = requests.get(
    f"{SERVER}/inbox/{RECEIVER}",
    headers=headers
)
response.raise_for_status()

messages = response.json().get("messages", [])

print("RECEIVER CLIENT")

if not messages:
    print("INBOX IS EMPTY.")

# PROCESS MESSAGE
for idx, msg in enumerate(messages, start=1):

    encrypted_sym_key = base64.b64decode(msg["encrypted_sym_key"])
    encrypted_message = base64.b64decode(msg["encrypted_message"])
    signature = base64.b64decode(msg["signature"])

    # verify signature
    try:
        sender_public_key.verify(signature, encrypted_message)
    except InvalidSignature:
        print(f"Pesan {idx}: Signature verification FAILED!")
        continue

    # verify ciphertext
    h = hashes.Hash(hashes.SHA256())
    h.update(encrypted_message)
    local_hash = base64.b64encode(h.finalize()).decode()

    if local_hash != msg["ciphertext_hash"]:
        print(f"Pesan {idx}: Integrity check FAILED!")
        continue

    # decrypt symmetric key (RSA priv key)
    symmetric_key = receiver_private_key.decrypt(
        encrypted_sym_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    # decrypt message (AES/Fernet)
    cipher = Fernet(symmetric_key)
    plaintext = cipher.decrypt(encrypted_message)
    
    print(f"Pesan {idx} dari {msg['from']}: {plaintext.decode()}")