from fastapi import FastAPI, HTTPException, UploadFile, File, Header
from pydantic import BaseModel
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
import base64, os, json
from jose import jwt, JWTError
from datetime import datetime, timedelta
import time
from fastapi import Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

app = FastAPI(title="Security Service - STELLA")
security = HTTPBearer()

ALLOWED_USERS = {"nasihuy", "jule"}
JWT_SECRET = "stella-secret-key"
JWT_ALGO = "HS256"
JWT_EXPIRE_MINUTES = 30
MAX_TIME_DIFF = 300

os.makedirs("data", exist_ok=True)
os.makedirs("inbox", exist_ok=True)
os.makedirs("punkhazard-keys", exist_ok=True)
  
def log_event(event: str):
    with open("server.log", "a", encoding="utf-8") as f:
        f.write(event + "\n")

def check_jwt(authorization: str) -> str:
    if not authorization:
        raise HTTPException(401, "Authorization header missing")

    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Invalid Authorization header")

    token = authorization.replace("Bearer ", "").strip()

    try:
        payload = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALGO],
            options={"verify_exp": False},
        )
        user_id = payload.get("sub")

        if not user_id:
            raise HTTPException(401, "Invalid token payload")

        if user_id not in ALLOWED_USERS:
            raise HTTPException(403, "User not allowed")

        return user_id

    except JWTError:
        raise HTTPException(401, f"Invalid token")

def check_timestamp(ts: int):
    if abs(time.time() - ts) > MAX_TIME_DIFF:
        raise HTTPException(400, "Message expired (possible replay attack)")

def sha256_digest(data: bytes) -> str:
    h = hashes.Hash(hashes.SHA256())
    h.update(data)
    return base64.b64encode(h.finalize()).decode()

# MODELS
class LoginRequest(BaseModel):
    user_id: str

class StoreKeyRequest(BaseModel):
    user_id: str
    public_key: str

class VerifyRequest(BaseModel):
    sender_id: str
    encrypted_message: str
    signature: str

class RelayRequest(BaseModel):
    sender_id: str
    receiver_id: str
    encrypted_message: str
    encrypted_sym_key: str
    signature: str
    message_id: str
    timestamp: int

class VerifyPDFRequest(BaseModel):
    sender_id: str
    pdf_hash: str
    signature: str


# ENDPOINTS
@app.get("/health")
def health():
    return {"status": "running"}

# LOGIN
@app.post("/login")
def login(data: LoginRequest):
    if data.user_id not in ALLOWED_USERS:
        raise HTTPException(403, "User not allowed")

    now = datetime.utcnow()
    payload = {
        "sub": data.user_id,
        "iat": int(now.timestamp()),
    }

    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

    log_event(f"[LOGIN] JWT issued for {data.user_id}")

    return {
        "access_token": token,
        "token_type": "bearer"
    }

# STORE PUBLIC KEY 
@app.post("/store")
def store_key(data: StoreKeyRequest, authorization: str = Header(..., alias="Authorization")):
    current_user = check_jwt(authorization)
    if current_user != data.user_id:
        raise HTTPException(403, "User mismatch")

    try:
        serialization.load_pem_public_key(data.public_key.encode())
    except Exception:
        raise HTTPException(400, "Invalid public key")

    with open(f"data/{data.user_id}_pubkey.txt", "w") as f:
        f.write(data.public_key)

    log_event(f"[STORE] Public key stored for {data.user_id}")
    return {"message": "Public key stored securely"}


# VERIFY SIGNATURE & INTEGRITY (Ed25519)
@app.post("/verify")
def verify(
    data: VerifyRequest,
    authorization: str = Header(..., alias="Authorization")
):
    current_user = check_jwt(authorization)
    
# ambil PUBLIC KEY SENDER
    pub_path = f"data/{data.sender_id}_pubkey.txt"
    if not os.path.exists(pub_path):
        raise HTTPException(404, "Sender public key not found")

    with open(pub_path, "rb") as f:
        public_key = serialization.load_pem_public_key(f.read())

    if not isinstance(public_key, Ed25519PublicKey):
        raise HTTPException(
            400,
            "Public key is not Ed25519 (signature algorithm mismatch)"
        )

    ciphertext = base64.b64decode(data.encrypted_message)
    signature = base64.b64decode(data.signature)

    try:
        public_key.verify(signature, ciphertext)
        original_valid = True
    except InvalidSignature:
        original_valid = False

    return {
        "verified": original_valid,
        "verified_using": data.sender_id,
        "algorithm": "Ed25519"
    }

# RELAY MESSAGE
@app.post("/relay")
def relay(data: RelayRequest, authorization: str = Header(..., alias="Authorization")):
    sender = check_jwt(authorization)
    if sender != data.sender_id:
        raise HTTPException(403, "Sender mismatch")

    check_timestamp(data.timestamp)

    if data.receiver_id not in ALLOWED_USERS:
        raise HTTPException(404, "Receiver not found")

    pub_path = f"data/{data.sender_id}_pubkey.txt"
    if not os.path.exists(pub_path):
        raise HTTPException(404, "Sender public key not found")

    try:
        with open(pub_path, "rb") as f:
            public_key = serialization.load_pem_public_key(f.read())
    except Exception:
        raise HTTPException(500, "Failed to load sender public key")

    try:
        signature = base64.b64decode(data.signature)
        ciphertext = base64.b64decode(data.encrypted_message)
    except Exception:
        raise HTTPException(400, "Invalid base64 encoding")

    message_hash = sha256_digest(ciphertext)

    try:
        public_key.verify(signature, ciphertext)
    except InvalidSignature:
        raise HTTPException(400, "Invalid signature")
    except Exception as e:
        raise HTTPException(500, f"Signature verification error: {str(e)}")

    inbox_path = f"inbox/{data.receiver_id}.json"
    messages = []

    if os.path.exists(inbox_path):
        with open(inbox_path, "r") as f:
            messages = json.load(f)

    messages.append({
        "message_id": data.message_id,
        "timestamp": data.timestamp,
        "from": data.sender_id,
        "signature": data.signature,
        "encrypted_message": data.encrypted_message,
        "encrypted_sym_key": data.encrypted_sym_key,
        "ciphertext_hash": message_hash
    })

    with open(inbox_path, "w", encoding="utf-8") as f:
        json.dump(messages, f, indent=2, ensure_ascii=False)

    log_event(f"[RELAY] {data.sender_id} → {data.receiver_id}")

    return {
        "status": "relayed securely",
        "verified": True
    }

# GET INBOX (receiver)
@app.get("/inbox/{user_id}")
def get_inbox(user_id: str, authorization: str = Header(..., alias="Authorization")):
    current_user = check_jwt(authorization)
    if current_user != user_id:
        raise HTTPException(403, "User mismatch")

    inbox_path = f"inbox/{user_id}.json"
    if not os.path.exists(inbox_path):
        return {"messages": []}

    with open(inbox_path, "r", encoding="utf-8") as f:
        messages = json.load(f)

    return {"messages": messages}

# PDF SIGN 
@app.post("/sign-pdf")
async def sign_pdf(
    user_id: str,
    file: UploadFile = File(...),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    # Ambil token dari Authorize
    authorization = f"Bearer {credentials.credentials}"

    current_user = check_jwt(authorization)
    if current_user != user_id:
        raise HTTPException(403, "User mismatch")

    content = await file.read()
    if not content:
        raise HTTPException(400, "Uploaded PDF is empty")

    digest = hashes.Hash(hashes.SHA256())
    digest.update(content)
    pdf_hash = digest.finalize()

    key_path = f"punkhazard-keys/{user_id}_rsa_priv.pem"
    if not os.path.exists(key_path):
        raise HTTPException(404, "Private key not found")

    with open(key_path, "rb") as f:
        private_key = serialization.load_pem_private_key(
            f.read(),
            password=None
        )

    signature = private_key.sign(
        pdf_hash,
        padding.PKCS1v15(),
        hashes.SHA256()
    )

    log_event(f"[PDF SIGN] Signed by {user_id}")

    return {
        "user": user_id,
        "pdf_hash": base64.b64encode(pdf_hash).decode(),
        "signature": base64.b64encode(signature).decode(),
        "algorithm": "SHA-256 + RSA",
        "status": "PDF signed successfully"
    }

# VERIFY PDF
@app.post("/verify-pdf")
def verify_pdf_signature(
    data: VerifyPDFRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    # JWT milik verifier (jule)
    authorization = f"Bearer {credentials.credentials}"
    current_user = check_jwt(authorization)

    # Ambil PUBLIC KEY PEMBUAT SIGNATURE
    pub_path = f"punkhazard-keys/{data.sender_id}_rsa_pub.pem"
    if not os.path.exists(pub_path):
        raise HTTPException(404, "Sender public key not found")

    with open(pub_path, "rb") as f:
        public_key = serialization.load_pem_public_key(f.read())

    try:
        public_key.verify(
            base64.b64decode(data.signature),
            base64.b64decode(data.pdf_hash),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return {
            "verified": True,
            "verified_by": current_user,
            "signed_by": data.sender_id,
            "algorithm": "RSA + SHA-256"
        }
    except InvalidSignature:
        return {
            "verified": False,
            "verified_by": current_user,
            "signed_by": data.sender_id
        }

